class PongLayer extends cc.Layer{
    constructor(){
        super();
        this.size = cc.winSize;

        let paddle = new Paddle(150, 25)
        let ball = new Ball(20)
        this.addChild(paddle);
        this.addChild(ball);
        
        let movePaddle = new MovePaddle();
        this.addComponent(movePaddle);

        this.scheduleUpdate();

        this.allChildren = this.getChildren();

        this.paddleSpeed = 350;
        this.paddleLeft = false;
        this.paddleRight = false;

        this.ballSpeed={
            x: Math.floor(Math.random() * 200) + 100,
            y: 300,
        }

        console.log(this.allChildren[0].x, this.allChildren[1].x)
    }

    update(dt){
        this.moveBall(dt)
        this.movePaddle(dt)
    }

    movePaddle(dt){
        if(this.paddleRight && this.allChildren[0].x < this.size.width/2 + 330)//has not hit right wall
            this.allChildren[0].setPosition(this.allChildren[0].x + this.paddleSpeed * dt, this.allChildren[0].y);
        if(this.paddleLeft && this.allChildren[0].x > 0)//has not hit left wall
            this.allChildren[0].setPosition(this.allChildren[0].x - this.paddleSpeed * dt, this.allChildren[0].y);
    }

    moveBall(dt){
        this.allChildren[1].setPosition(this.allChildren[1].x + (this.ballSpeed.x * dt), this.allChildren[1].y - this.ballSpeed.y * dt)

        if(this.allChildren[1].x >= this.size.width-21 || this.allChildren[1].x <= 21)//change direction if hit side walls
            this.ballSpeed.x *= -1;
        if(this.allChildren[1].y >= this.size.height - 20 ||(this.allChildren[1].y <= 65 && this.allChildren[1].x>=this.allChildren[0].x && this.allChildren[1].x <= this.allChildren[0].x + 150))//change direction if ball hits paddle or ceiling
            this.ballSpeed.y *= -1;
        if(this.allChildren[1].y < 0)//if ball hits bottom wall proceed to game over screen
            cc.director.runScene(new GameOverScene())
    }
}